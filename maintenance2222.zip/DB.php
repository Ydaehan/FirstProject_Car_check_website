<?php
//db연결 정보
include("maintenance.php");


//mysqli 객체 생성
$connect = mysqli_connect("localhost", "root", "", "caruser_info") or die("fail");

//연결 확인
if($connect -> connect_error){
  die("Connection failed: " . $connect->connect_error);
}

$sql = "SELECT driven_distance FROM user_car_data" ;

$result = $connect->query($sql);

if($result){
  $num_rows = $result->num_rows;

}else{
 
}





?>