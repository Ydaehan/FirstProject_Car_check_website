<!-- 







//베터리
//타이어
//파워스티어링 오일

 -->
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<link rel="stylesheet" type="text/css" href="./maintenance.css">
<script>
  //다음 정비까지 남은 km를 구하는 함수
    function maintenance_mileage(driving_distance,cycle) {
    remaining_distance = driving_distance - cycle
    return remaining_distance;
  }
    var cycleAirConFilter = 5000;         //에어컨 필터
    var cycleEnginOil = 15000;            //엔진오일 및 오일필터
    var cycleWiperBlade = 8000;           //와이퍼 블레이드
    var cycleBlakeOil = 45000;            //블레이크 오일
    var cycleAirCleanerFilter = 40000;    //에어클리너 필터
    var cycleEngineAntifreeze = 40000;    //엔진부동액
    var cycleDriveBelt = 60000;           //구동벨트

    var driving_distance1 = 4563; //현재까지 주행 거리 @@주의@@(db로 받아야함)
   
  </script>
<body >

  <p>안녕하세요 정비 주기를 알려드릴게요ㅎㅎ</p>
  

  <?php
  echo "<script>document.write(maintenance_mileage(cycleAirConFilter,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://cdn-icons-png.flaticon.com/512/900/900094.png"     class = "aircon" />
  <p>에어컨 필터</p>
  
  <?php
  echo "<script>document.write(maintenance_mileage(cycleEnginOil,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://cdn-icons-png.flaticon.com/512/4633/4633013.png"     class = "enginOil" />
  <p>엔진오일 및 오일필터</p>
  
  <?php
  echo "<script>document.write(maintenance_mileage(cycleWiperBlade,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://cdn-icons-png.flaticon.com/512/5999/5999420.png"     class = "wiper" />
  <p>와이퍼 블레이드</p>
  
  <?php
  echo "<script>document.write(maintenance_mileage(cycleBlakeOil,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://us.123rf.com/450wm/leshkasmok/leshkasmok1503/leshkasmok150300126/37976958-%EB%B8%8C%EB%A0%88%EC%9D%B4%ED%81%AC-%EC%95%A1%EC%97%90-%EB%AC%B8%EC%A0%9C%EA%B0%80-%EC%9E%88%EC%8A%B5%EB%8B%88%EB%8B%A4-%ED%9D%B0%EC%83%89-%EB%B0%B0%EA%B2%BD%EC%97%90-%EB%8B%A8%EC%9D%BC-%ED%8F%89%EB%A9%B4-%EC%95%84%EC%9D%B4%EC%BD%98.jpg?ver=6""     class = "blakeOil" />
  
  <p>블레이크 오일</p>
  <?php
  echo "<script>document.write(maintenance_mileage(cycleAirCleanerFilter,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://w7.pngwing.com/pngs/105/725/png-transparent-filter-heroicons-ui-icon.png"     class = "airCleaner" />
  
  <p>에어클리너 필터</p>
  <?php
  echo "<script>document.write(maintenance_mileage(cycleEngineAntifreeze ,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://cdn-icons-png.flaticon.com/512/95/95134.png?w=360"     class = "enginAntifreeze" />
  
  <p>엔진부동액</p>
  <?php
  echo "<script>document.write(maintenance_mileage(cycleDriveBelt,driving_distance1));</script>km 남음";
  ?>
  <img src = "https://cdn-icons-png.flaticon.com/512/1894/1894556.png"     class = "DriveBelt" />
  <p>구동벨트</p>

  

</body>
</html>
 
