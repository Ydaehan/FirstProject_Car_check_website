<?php

$db = mysqli_connect("localhost", "root", "", "test");
if(!$db){
  echo "DB접속 실패";
}






?>